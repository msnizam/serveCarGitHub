export interface Admin{
  email: string;
  password: string;
}
